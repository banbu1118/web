const btn = document.getElementById("btn")
alert(btn)
