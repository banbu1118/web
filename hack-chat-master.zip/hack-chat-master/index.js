console.log('Use "npm start" instead.')
