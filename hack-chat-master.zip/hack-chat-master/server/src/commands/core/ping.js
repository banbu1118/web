/*
  Description: This module is only in place to supress error notices legacy sources may get
*/

// module main
export async function run() { }

export const info = {
  name: 'ping',
  description: 'This module is only in place to supress error notices legacy sources may get',
};
